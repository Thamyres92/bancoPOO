package banco_modelo;

public class ContaSalario implements IConta{
	
	String numeroConta;
	String agencia;
	private float saldo;
	boolean status;
	String dataAbertura;
	
	public ContaSalario(String numeroConta, String agencia, String dataAbertura) {
		this.numeroConta = numeroConta;
		this.agencia = agencia;
		this.dataAbertura = dataAbertura;
		this.saldo = 0f;
		this.status = true;
		
	}
	
	

	@Override
	public String toString() {
		return "ContaSalario [numeroConta=" + numeroConta + ", agencia=" + agencia + ", saldo=" + saldo + ", status="
				+ status + ", dataAbertura=" + dataAbertura + "]";
	}



	@Override
	public void sacar(float valorSacado) {
		if(valorSacado >= 0 && this.saldo >= valorSacado && this.status) {
			this.saldo -= valorSacado;
		} else if (valorSacado <= 0) {
			System.err.println("Valor informado incorreto!");
		} else if (this.status == false) {
			System.err.println("Conta desativada, imposs�vel de sacar");
		} else {
			System.err.println("Imposs�vel realizar o saque");
		}
		
	}

	@Override
	public void depositar(float valorDepositado) {
		if (valorDepositado>0 && this.status) {
			this.saldo += valorDepositado;
		} else if (valorDepositado <= 0) {
			System.err.println("Valor insuficiente para ser depositado!");
		} else if (this.status == false) {
			System.err.println("Conta inativa, imposs�vel depositar");
		} else {
			System.err.println("Imposs�vel depositar");
		}
		
	}

	@Override
	public void ativarConta() {
		this.status = true;
		
	}

	@Override
	public void desativarConta() {
		this.status = false;
		
	}

	@Override
	public void transferir(IConta contaDestino, float valorTransferido) {
		System.err.println("Conta sal�rio n�o realiza transfer�ncia.");
		
	}

}
