package banco_modelo;

public class Programa {

	public static void main(String[] args) {
		
		IConta c1 = new ContaCorrente("123", "123", "14/01/2021");
		
		IConta c2 = new ContaPoupanca("456", "456", "14/01/2021");
		
		IConta c3 = new ContaInvestimento("789", "789", "14/01/2021");
		
		IConta c4 = new ContaSalario("000", "000", "14/01/2021");
		
		Cliente cliente1 = new Cliente("Poliana", "000", "04/02/1998", "psq@hotmail.com");
		
		Cliente cliente2 = new Cliente("Thamyres", "111", "04/07/1999", "tmq@hotmail.com");
		
		
		cliente1.adicionarTelefone("343154785");
		cliente2.adicionarTelefone("1653213132");
		
		cliente1.adicionarConta(c1);
		cliente2.adicionarConta(c3);
		
		System.out.println("Contas criadas sem saldo: ");
		System.out.println(cliente1);
		System.out.println(cliente2);
		
		c1.depositar(1000f);
		c3.depositar(1500f);
		
		System.out.println("Contas com novo saldo");
		System.out.println(cliente1);
		System.out.println(cliente2);
		
		c1.sacar(500f);
		c3.sacar(500f);
		
		System.out.println("Contas ap�s saque");
		System.out.println(cliente1);
		System.out.println(cliente2);
		
		cliente1.adicionarConta(c4);
		c4.transferir(c3, 500f);
		
		
		c3.transferir(c1, 200f);
		System.out.println("Contas ap�s transferencia");
		System.out.println(cliente1);
		System.out.println(cliente2);

	}

}
