package banco_modelo;

public interface IConta {
	
	float TAXA_SACAR_CONTA_CORRENTE = 0.01f;
	float TAXA_SACAR_CONTA_POUPANCA = 0.02f;
	float TAXA_SACAR_CONTA_INVESTIMENTO = 0.05f;
	
	float TAXA_ADM_POUPANCA = 0.03f;
	float TAXA_ADM_CORRENTE = 0.04f;
	float TAXA_ADM_INVESTIMENTO = 0.05f;
	float TAXA_ADM_SALARIO = 0.01f;
	
	float RENDIMENTO_POUPANCA = 0.03f;
	
	
	public void sacar(float valorSacado);
	
	public void depositar(float valorDepositado);
	
	public void ativarConta();
	
	public void desativarConta();
	
	public void transferir(IConta contaDestino, float valorTransferido);
	
	public String toString();
}
